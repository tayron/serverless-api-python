def hello_world(event, context):
    return {
        "status": 200,
        "body": "Hello World"
    }